This package contains some common ready to use functions. The primary focus is provide pre-coded functions used in 
Data Structures and Algorithm problems.

Note: This package is developed and maintained by a learning student. Please don't mind the mistakes :)